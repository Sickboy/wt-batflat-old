const eatScore 	= 100;
const timeScore = -2;
const dirScore 	= 1;

const initScore = 100;
const initLearn = 1;

class Snake {	
  constructor(gen, brain) {
	this.generation = (gen?gen:1);
    this.x = 200;
    this.y = 200;
    this.xspeed = 1;
    this.yspeed = 0;
    this.total = 0;
    this.tail = [];

    this.score = initScore;
    this.fitness = 0;

    if (brain) {
      this.brain = brain.copy();
    } else {
      this.brain = new NeuralNetwork(8 ,16, 4);
    }
    
  }

  eat(food) {
    var d = dist(this.x, this.y, food.x, food.y);
    if (d < 1) {
      this.total++;
      this.score += eatScore;
      return true;
    } else {
      return false;
    }
  }

  dir(x, y) {
	if(this.xspeed ==0 || this.xspeed !== - x)
		this.xspeed = x;
	if(this.yspeed ==0 || this.yspeed !== - y)
		this.yspeed = y;
  }

  update() {
    for (var i = 0; i < this.tail.length - 1; i++) {
      this.tail[i] = this.tail[i + 1];
    }
    if (this.total >= 1) {
      this.tail[this.total - 1] = createVector(this.x, this.y);
    }

    this.x = this.x + this.xspeed * scl;
    this.y = this.y + this.yspeed * scl;

    //this.x = constrain(this.x, 0, width - scl);
    //this.y = constrain(this.y, 0, height - scl);

    //update score
    this.score += timeScore;
  }

  show() {
    fill(255, 100);
    for (var i = 0; i < this.tail.length; i++) {
      rect(this.tail[i].x, this.tail[i].y, scl, scl);
    }
    rect(this.x, this.y, scl, scl);
  }

  isDead() {
    //if hit the wall
    if(this.x < 0 || this.x >= 600 || this.y < 0 || this.y >= 600 )
      return true;
    //or hit the tail
    for (var i = 0; i < this.tail.length; i++) {
      let pos = this.tail[i];
      var d = dist(this.x, this.y, pos.x, pos.y);
      if (d < 1) {
        return true;
      }
    }
    return false;
  }

  
 // Neural network functions
  think(food) {
	this.addScore(food);
    let inputs = [];
	
    inputs[0] = (this.x>=(600-scl)?1:0);
    inputs[1] = (this.y>=(600-scl)?1:0);
	inputs[2] = (this.x<(0+scl)?1:0);
    inputs[3] = (this.y<(0+scl)?1:0);
    inputs[4] = (this.x - food.x); 
    inputs[5] = (this.y - food.y);
    inputs[6] = this.xspeed;
    inputs[7] = this.yspeed;

    let output = this.brain.predict(inputs);
    this.setDir(indexOfMax(output));
  }

  mutate() {
    this.brain.mutate(initLearn / (this.generation ));
  }

  addScore(food) {
	let dx = this.x - food.x;
	let dy = this.y - food.y;
	let d = decodeDir(this.xspeed, this.yspeed);
	
	if(dx < 0 && dy < 0){
		if(d === 0 || d === 2)
			this.score += dirScore;
	}
	if(dx < 0 && dy > 0){
		if(d === 1 || d === 2)
			this.score += dirScore;
	}
	if(dx > 0 && dy > 0){
		if(d === 1 || d === 3)
			this.score += dirScore;
	}
	if(dx > 0 && dy < 0){
		if(d === 0 || d === 3)
			this.score += dirScore;
	}	
	
  } 
  
  //convert brain output to snake direction
  setDir(a) {
    if (a === 0) {
      this.dir(0, -1);
    } else if (a === 1) {
      this.dir(0, 1);
    } else if (a === 2) {
      this.dir(1, 0);
    } else if (a === 3) {
      this.dir(-1, 0);
    } else
      this.dir(0, -1);
  }

  
}


// MISC
function decodeDir(x, y){
     if (x === 0 && y === -1)
		return 0;
    else if (x === 0 && y === 1)
		return 1;
    else if (x === 1 && y === 0)
		return 2;
    else if (x === -1 && y === 0) 
		return 3;
    else
		return -1;
  
  }

function indexOfMax(a) {
   var max = 0;
   for (var i = 1; i < a.length; i++) {
      if (a[i] > a[max]) max = i;
   }
   return max;
}