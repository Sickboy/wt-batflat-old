const TOTAL = 1;
const brainFile = 'brain.json';

var scl = 40;

const SPEED = 10;
var snakes;
var foods;

var savedSnakes = [];

let cntr = 0;
let preloadedBrain;
let brainJSON;

function preload() {
  brainJSON = loadJSON(brainFile);
}

function setup() {
  createCanvas(600, 600);
  frameRate(SPEED);
  startGame();
}

function pickLocation() {
  let food;
  var cols = floor(width/scl);
  var rows = floor(height/scl);
  food = createVector(floor(random(cols)), floor(random(rows)));
  food.mult(scl);
  return food;
}

function draw() {
	  cntr++;	  
  for(let i = 0; i < snakes.length; i++){
	let s = snakes[i];
	
	if (s.eat(foods[i])) {
	  foods[i] = pickLocation();
	}

	s.think(foods[i]);
	s.update();

	if(s.isDead() || s.score <= 0){
	  savedSnakes.push(snakes.splice(i,1)[0]);
	  foods.splice(i,1)
	}  

  }
  
  //drawing stuff
  background(51);
  fill(255, 0, 100);
  for(let food of foods)
    rect(food.x, food.y, scl, scl);
  for(let s of snakes)
    s.show();

  if (snakes.length === 0 ){   
	cntr = 0;
    startGame();
  }
  

}


function startGame(){
	preloadedBrain = NeuralNetwork.deserialize(brainJSON);
	if(snakes)
		if(snakes.length > 0)
			for(let s of snakes)
				savedSnakes.push(s);
	//restart the game after running out of snakes
	snakes = [];
	foods = [];
	counter = 0;
	for(let i = 0; i< TOTAL;i++)
		snakes[i] = new Snake(1, preloadedBrain);
	for(let i = 0; i< TOTAL;i++)
		foods[i] = pickLocation();


}



function keyPressed() {
  let s = snakes[0];
  if (keyCode === UP_ARROW) {
    s.dir(0, -1);
  } else if (keyCode === DOWN_ARROW) {
    s.dir(0, 1);
  } else if (keyCode === RIGHT_ARROW) {
    s.dir(1, 0);
  } else if (keyCode === LEFT_ARROW) {
    s.dir(-1, 0);
  }

  if (key === 'S') {;
    saveJSON(s.brain, 'snake.json');
  }
  
  if (key === 'N') {
    startGame();
  }
}
